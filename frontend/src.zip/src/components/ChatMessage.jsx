import { useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  Bot,
  User,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  FileText,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

function ChatMessage({ sender, text, sources = [] }) {
  const isUser = sender === "user";

  const [copied, setCopied] = useState(false);
  const [showSources, setShowSources] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);

      setCopied(true);

      setTimeout(() => {
        setCopied(false);
      }, 2000);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex mb-6 ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      <div
        className={`flex items-start gap-4 max-w-[85%] ${
          isUser ? "flex-row-reverse" : ""
        }`}
      >
        {/* Avatar */}

        <div
          className={`w-11 h-11 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0 ${
            isUser
              ? "bg-gradient-to-r from-blue-500 to-cyan-500"
              : "bg-slate-800 border border-slate-700"
          }`}
        >
          {isUser ? (
            <User size={20} className="text-white" />
          ) : (
            <Bot size={20} className="text-cyan-400" />
          )}
        </div>

        {/* Message */}

        <div
          className={`rounded-2xl px-5 py-4 shadow-lg border ${
            isUser
              ? "bg-gradient-to-r from-blue-600 to-cyan-500 border-blue-500 text-white"
              : "bg-slate-800 border-slate-700 text-slate-100"
          }`}
        >
          {!isUser && (
            <>
              <div className="flex items-center justify-between mb-4">
                <p className="text-xs uppercase tracking-wider text-cyan-400 font-semibold">
                  DocMind AI
                </p>

                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-slate-400 transition hover:bg-slate-700 hover:text-white"
                >
                  {copied ? (
                    <>
                      <Check size={14} />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy size={14} />
                      Copy
                    </>
                  )}
                </button>
              </div>

              <div className="prose prose-invert prose-sm max-w-none">
                <ReactMarkdown>{text}</ReactMarkdown>
              </div>

              {/* Sources */}

              {sources.length > 0 && (
                <div className="mt-6 border-t border-slate-700 pt-4">
                  <button
                    onClick={() => setShowSources(!showSources)}
                    className="flex w-full items-center justify-between rounded-xl bg-slate-900 px-4 py-3 transition hover:bg-slate-700"
                  >
                    <div className="flex items-center gap-2">
                      <FileText
                        size={18}
                        className="text-cyan-400"
                      />

                      <span className="font-medium text-white">
                        Sources Used ({sources.length})
                      </span>
                    </div>

                    {showSources ? (
                      <ChevronUp size={18} />
                    ) : (
                      <ChevronDown size={18} />
                    )}
                  </button>

                  <AnimatePresence>
                    {showSources && (
                      <motion.div
                        initial={{
                          opacity: 0,
                          height: 0,
                        }}
                        animate={{
                          opacity: 1,
                          height: "auto",
                        }}
                        exit={{
                          opacity: 0,
                          height: 0,
                        }}
                        transition={{
                          duration: 0.25,
                        }}
                        className="overflow-hidden"
                      >
                        <div className="space-y-4 mt-4">
                          {sources.map((source, index) => (
                            <div
                              key={index}
                              className="rounded-xl border border-slate-700 bg-slate-900 p-4"
                            >
                              <div className="flex items-center gap-2 mb-3">
                                <FileText
                                  size={16}
                                  className="text-cyan-400"
                                />

                                <span className="text-sm font-semibold text-cyan-400">
                                  Source {source.chunk}
                                </span>
                              </div>

                              <p className="text-sm leading-7 text-slate-300 whitespace-pre-wrap">
                                {source.content.length > 350
                                  ? source.content.substring(0, 350) +
                                    "..."
                                  : source.content}
                              </p>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </>
          )}

          {isUser && (
            <p className="leading-7 whitespace-pre-wrap">
              {text}
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default ChatMessage;