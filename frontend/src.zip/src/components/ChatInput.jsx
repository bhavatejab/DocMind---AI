import { useState } from "react";
import { SendHorizontal, Lock } from "lucide-react";
import { motion } from "framer-motion";

function ChatInput({ onSend, loading, disabled }) {
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const trimmed = message.trim();

    if (!trimmed || loading || disabled) return;

    onSend(trimmed);
    setMessage("");
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="sticky bottom-0 mt-6"
    >
      <div
        className={`flex items-center gap-3 rounded-2xl border p-3 shadow-xl transition ${
          disabled
            ? "border-slate-800 bg-slate-900"
            : "border-slate-700 bg-slate-800"
        }`}
      >
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          disabled={loading || disabled}
          placeholder={
            disabled
              ? "Upload a PDF to start chatting with DocMind AI..."
              : "Ask anything about your document..."
          }
          className="flex-1 bg-transparent px-3 py-3 text-white placeholder:text-slate-500 outline-none disabled:cursor-not-allowed"
        />

        <button
          type="submit"
          disabled={loading || disabled}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 px-5 py-3 font-semibold text-white transition hover:scale-105 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {disabled ? (
            <Lock size={18} />
          ) : (
            <SendHorizontal size={18} />
          )}

          {loading
            ? "Sending..."
            : disabled
            ? "Locked"
            : "Send"}
        </button>
      </div>
    </motion.form>
  );
}

export default ChatInput;