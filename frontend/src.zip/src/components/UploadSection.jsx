import { useRef, useState } from "react";
import {
  Upload,
  FileText,
  CheckCircle2,
  Trash2,
} from "lucide-react";

import { uploadPDF } from "../services/api";

function UploadSection({
  fileName,
  onUploadSuccess,
  onRemoveFile,
}) {
  const fileInputRef = useRef(null);

  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");

  const handleClick = () => {
    fileInputRef.current.click();
  };

  const uploadSelectedFile = async (file) => {
    if (!file || file.type !== "application/pdf") {
      alert("Please select a PDF file.");
      return;
    }

    try {
      setLoading(true);
      setStatus("");

      const response = await uploadPDF(file);

      onUploadSuccess(file.name);

      setStatus(response.message);
    } catch (error) {
      console.error(error);
      setStatus("Upload failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (event) => {
    uploadSelectedFile(event.target.files[0]);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = () => {
    setDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragActive(false);

    uploadSelectedFile(e.dataTransfer.files[0]);
  };

  const removeFile = () => {
    setStatus("");

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    onRemoveFile();
  };

  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold text-white mb-5">
        Upload to DocMind AI
      </h2>

      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`rounded-3xl border-2 transition-all duration-300 p-10 ${
          dragActive
            ? "border-blue-500 bg-slate-800"
            : "border-slate-700 bg-slate-800"
        }`}
      >
        <div className="flex flex-col items-center">
          <div className="rounded-full bg-blue-600/20 p-5 mb-5">
            <Upload size={42} className="text-blue-400" />
          </div>

          <h3 className="text-3xl font-bold text-white">
            Upload Your PDF
          </h3>

          <p className="text-slate-400 mt-3">
            Drag & Drop your document here
          </p>

          <p className="text-slate-500 my-4">
            OR
          </p>

          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf"
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            onClick={handleClick}
            disabled={loading}
            className="rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 px-8 py-4 font-semibold text-white shadow-lg transition hover:scale-105 disabled:opacity-60"
          >
            {loading ? "Uploading..." : "Browse Files"}
          </button>

          <p className="mt-5 text-sm text-slate-500">
            Supports PDF • Maximum Size 10 MB
          </p>
        </div>

        {fileName && (
          <div className="mt-10 rounded-2xl border border-green-500/30 bg-green-500/10 p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="rounded-xl bg-green-500/20 p-3">
                  <FileText
                    className="text-green-400"
                    size={28}
                  />
                </div>

                <div>
                  <p className="font-semibold text-white">
                    {fileName}
                  </p>

                  <div className="flex items-center gap-2 mt-1">
                    <CheckCircle2
                      size={16}
                      className="text-green-400"
                    />

                    <span className="text-green-400 text-sm">
                      {status || "Ready to chat"}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={removeFile}
                className="rounded-lg bg-red-500/20 p-3 transition hover:bg-red-500"
              >
                <Trash2
                  size={18}
                  className="text-red-300"
                />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

export default UploadSection;